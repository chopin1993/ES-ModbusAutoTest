#!/bin/sh

check_main()
{
	if test $( pidof modbus_svr | wc -l ) -eq 0;
	then
		cd /gateway/modbus/
		nohup ./modbus_svr > /dev/null 2>&1 &
	fi
}


while true
do
	check_main
	sleep 60
done
