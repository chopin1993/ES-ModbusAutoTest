#!/bin/sh

if test $(cat /usr/sbin/gateway_boot.sh | grep mbsvr_start | wc -l) -eq 0
then
	echo "set modbus srv autorun after pwoer on."
	echo -e "/gateway/modbus/mbsvr_start.sh &" >> /usr/sbin/gateway_boot.sh
else
	echo "allready set modbus svr autoboot."
fi
